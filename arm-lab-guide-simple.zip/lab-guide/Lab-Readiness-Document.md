# Lab Readiness Document
## ARM Template Infrastructure with RBAC – Assessment 6

| Field | Details |
|---|---|
| **Lab Title** | Deploy Azure Infrastructure with ARM Templates and RBAC |
| **Platform** | CloudLabs |
| **Duration** | 45 minutes |
| **Difficulty** | Beginner–Intermediate |
| **Region** | Central India |

---

## Deliverables

| Item | Status |
|---|---|
| Main ARM Template (`azuredeploy.json`) | ✅ Ready |
| Nested RBAC Template (`nested-rbac.json`) | ✅ Ready |
| Parameter File (`azuredeploy.parameters.json`) | ✅ Ready |
| Lab Guide (single page, 1 exercise + assessment) | ✅ Ready |
| Readiness Document | ✅ This Document |

---

## Template Checklist

| Check | Result |
|---|---|
| JSON syntax valid | ✅ |
| NSG attached to subnet and NIC | ✅ |
| `osDisk` present in both VMs | ✅ |
| VM size `Standard_B2s` (4GB RAM) | ✅ |
| `enableAutomaticUpdates` set to false | ✅ |
| No hardcoded credentials | ✅ |
| Custom role permissions match constraints | ✅ |
| Role assigned via `principalId` parameter | ✅ |

---

## Known Issues

| Issue | Fix |
|---|---|
| DWM crash on RDP | VM size must be `Standard_B2s`, not `Standard_B1s` |
| Role assignment not visible immediately | Wait 1–2 min and refresh IAM page |
| Nested template 404 | Blob container must have Public access |

---

## Inject Keys Used

| Key | Purpose |
|---|---|
| `AzureAdUserEmail` | Portal login username |
| `AzureAdUserPassword` | Portal login password |
| `resourceGroupName` | Pre-provisioned resource group |
| `ApplicationID` | Principal ID for role assignment |

---

## Master Document (masterdoc.json)

```json
{
  "Name": "Deploy Azure Infrastructure with ARM Templates and RBAC",
  "Language": "English",
  "Files": [
    { "RawFilePath": "<RAW_GITHUB_URL>/Instructions/Lab-Guide.md", "Order": 1 }
  ]
}
```

---

## Sign-off

| Role | Name | Approved |
|---|---|---|
| Lab Author | | ☐ |
| Technical Reviewer | | ☐ |
| CloudLabs Admin | | ☐ |
